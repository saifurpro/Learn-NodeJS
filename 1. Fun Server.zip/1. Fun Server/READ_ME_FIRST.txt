After downloading this file
1) open Terminal
2) write the code: "node fun.js" // Make sure you have installed nodejs
4) Open any Browser
5) http://localhost:3000/
